import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:gym/providers/auth_provider.dart';
import 'package:gym/screens/auth/login_screen.dart';
import 'package:gym/screens/members/member_list_screen.dart';
import 'package:gym/screens/packages/package_list_screen.dart';
import 'package:gym/screens/trainers/trainer_list_screen.dart';
import 'package:gym/screens/attendance/attendance_screen.dart';
import 'package:gym/screens/finance/transaction_list_screen.dart';
import 'package:gym/screens/settings/settings_screen.dart';
import 'package:gym/screens/subscriptions/subscription_list_screen.dart';
import 'package:gym/screens/payments/payment_list_screen.dart';
import 'package:gym/screens/training_sessions/training_session_list_screen.dart';
import 'package:gym/screens/finance/savings_list_screen.dart';
import 'package:gym/screens/reports/financial_report_screen.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);
    final user = authProvider.currentUser;
    final isAdmin = user?.role == 'admin';

    return Scaffold(
      appBar: AppBar(
        title: const Text('Dashboard'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () async {
              await authProvider.logout();
              if (context.mounted) {
                Navigator.of(context).pushReplacement(
                  MaterialPageRoute(builder: (_) => const LoginScreen()),
                );
              }
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Card(
              elevation: 4,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    const CircleAvatar(
                      radius: 30,
                      backgroundColor: Colors.green,
                      child: Icon(
                        Icons.person,
                        size: 30,
                        color: Colors.white,
                      ),
                    ),
                    const SizedBox(width: 16),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Selamat Datang, ${user?.username ?? "Pengguna"}',
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text(
                          'Role: ${user?.role ?? "Staff"}',
                          style: const TextStyle(
                            color: Colors.grey,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              'Menu Utama',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 10),
            GridView.count(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisCount: 2,
              crossAxisSpacing: 10,
              mainAxisSpacing: 10,
              children: [
                _buildMenuCard(
                  context,
                  'Anggota',
                  Icons.people,
                  Colors.blue,
                  () {
                    Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => const MemberListScreen()),
                    );
                  },
                ),
                _buildMenuCard(
                  context,
                  'Paket Membership',
                  Icons.card_membership,
                  Colors.orange,
                  () {
                    Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => const PackageListScreen()),
                    );
                  },
                ),
                _buildMenuCard(
                  context,
                  'Langganan',
                  Icons.subscriptions,
                  Colors.purple,
                  () {
                    Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => const SubscriptionListScreen()),
                    );
                  },
                ),
                _buildMenuCard(
                  context,
                  'Pembayaran',
                  Icons.payment,
                  Colors.green,
                  () {
                    Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => const PaymentListScreen()),
                    );
                  },
                ),
                _buildMenuCard(
                  context,
                  'Pelatih',
                  Icons.sports,
                  Colors.indigo,
                  () {
                    Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => const TrainerListScreen()),
                    );
                  },
                ),
                _buildMenuCard(
                  context,
                  'Sesi Pelatihan',
                  Icons.fitness_center,
                  Colors.deepPurple,
                  () {
                    Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => const TrainingSessionListScreen()),
                    );
                  },
                ),
                _buildMenuCard(
                  context,
                  'Absensi',
                  Icons.calendar_today,
                  Colors.teal,
                  () {
                    Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => const AttendanceScreen()),
                    );
                  },
                ),
                if (isAdmin)
                  _buildMenuCard(
                    context,
                    'Keuangan',
                    Icons.attach_money,
                    Colors.green,
                    () {
                      Navigator.of(context).push(
                        MaterialPageRoute(builder: (_) => const TransactionListScreen()),
                      );
                    },
                  ),
                if (isAdmin)
                  _buildMenuCard(
                    context,
                    'Tabungan',
                    Icons.savings,
                    Colors.amber,
                    () {
                      Navigator.of(context).push(
                        MaterialPageRoute(builder: (_) => const SavingsListScreen()),
                      );
                    },
                  ),
                if (isAdmin)
                  _buildMenuCard(
                    context,
                    'Laporan Keuangan',
                    Icons.bar_chart,
                    Colors.blue,
                    () {
                      Navigator.of(context).push(
                        MaterialPageRoute(builder: (_) => const FinancialReportScreen()),
                      );
                    },
                  ),
                if (isAdmin)
                  _buildMenuCard(
                    context,
                    'Pengaturan',
                    Icons.settings,
                    Colors.grey,
                    () {
                      Navigator.of(context).push(
                        MaterialPageRoute(builder: (_) => const SettingsScreen()),
                      );
                    },
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMenuCard(
    BuildContext context,
    String title,
    IconData icon,
    Color color,
    VoidCallback onTap,
  ) {
    return Card(
      elevation: 4,
      child: InkWell(
        onTap: onTap,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircleAvatar(
              radius: 30,
              backgroundColor: color.withOpacity(0.2),
              child: Icon(
                icon,
                size: 30,
                color: color,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              title,
              style: const TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
