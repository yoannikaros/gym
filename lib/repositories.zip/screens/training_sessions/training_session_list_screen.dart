import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:gym/models/member.dart';
import 'package:gym/models/trainer.dart';
import 'package:gym/models/training_session.dart';
import 'package:gym/repositories/member_repository.dart';
import 'package:gym/repositories/trainer_repository.dart';
import 'package:gym/repositories/training_session_repository.dart';
import 'package:gym/screens/training_sessions/training_session_form_screen.dart';
import 'package:gym/utils/date_formatter.dart';

class TrainingSessionListScreen extends StatefulWidget {
  final int? trainerId;
  final int? memberId;

  const TrainingSessionListScreen({
    super.key,
    this.trainerId,
    this.memberId,
  });

  @override
  State<TrainingSessionListScreen> createState() => _TrainingSessionListScreenState();
}

class _TrainingSessionListScreenState extends State<TrainingSessionListScreen> {
  final TrainingSessionRepository _sessionRepository = TrainingSessionRepository();
  final TrainerRepository _trainerRepository = TrainerRepository();
  final MemberRepository _memberRepository = MemberRepository();
  
  List<TrainingSession> _sessions = [];
  Map<int, Trainer> _trainers = {};
  Map<int, Member> _members = {};
  
  bool _isLoading = true;
  DateTime _selectedDate = DateTime.now();

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() {
      _isLoading = true;
    });

    try {
      List<TrainingSession> sessions;
      
      // Filter sessions based on parameters
      if (widget.trainerId != null) {
        sessions = await _sessionRepository.getTrainingSessionsByTrainerId(widget.trainerId!);
      } else if (widget.memberId != null) {
        sessions = await _sessionRepository.getTrainingSessionsByMemberId(widget.memberId!);
      } else {
        // Filter by selected date
        final formattedDate = DateFormat('yyyy-MM-dd').format(_selectedDate);
        sessions = await _sessionRepository.getTrainingSessionsByDate(formattedDate);
      }
      
      // Get all related trainers and members
      final trainerIds = sessions.map((s) => s.trainerId).toSet().toList();
      final memberIds = sessions.map((s) => s.memberId).toSet().toList();
      
      final trainerMap = <int, Trainer>{};
      final memberMap = <int, Member>{};
      
      for (var id in trainerIds) {
        final trainer = await _trainerRepository.getTrainerById(id);
        if (trainer != null) {
          trainerMap[id] = trainer;
        }
      }
      
      for (var id in memberIds) {
        final member = await _memberRepository.getMemberById(id);
        if (member != null) {
          memberMap[id] = member;
        }
      }
      
      setState(() {
        _sessions = sessions;
        _trainers = trainerMap;
        _members = memberMap;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error: ${e.toString()}'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> _deleteSession(int id) async {
    try {
      await _sessionRepository.deleteTrainingSession(id);
      await _loadData();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Sesi pelatihan berhasil dihapus'),
            backgroundColor: Colors.green,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error: ${e.toString()}'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );
    
    if (picked != null && picked != _selectedDate) {
      setState(() {
        _selectedDate = picked;
      });
      _loadData();
    }
  }

  @override
  Widget build(BuildContext context) {
    String title = 'Sesi Pelatihan';
    if (widget.trainerId != null && _trainers.containsKey(widget.trainerId)) {
      title = 'Sesi Pelatih: ${_trainers[widget.trainerId!]!.name}';
    } else if (widget.memberId != null && _members.containsKey(widget.memberId)) {
      title = 'Sesi Anggota: ${_members[widget.memberId!]!.name}';
    }

    return Scaffold(
      appBar: AppBar(
        title: Text(title),
        actions: [
          if (widget.trainerId == null && widget.memberId == null)
            IconButton(
              icon: const Icon(Icons.calendar_today),
              onPressed: () => _selectDate(context),
            ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                if (widget.trainerId == null && widget.memberId == null)
                  Padding(
                    padding: const EdgeInsets.all(16),
                    child: Text(
                      'Tanggal: ${DateFormat('dd MMMM yyyy').format(_selectedDate)}',
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                Expanded(
                  child: _sessions.isEmpty
                      ? Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const Text('Tidak ada sesi pelatihan'),
                              const SizedBox(height: 16),
                              ElevatedButton(
                                onPressed: () async {
                                  final result = await Navigator.of(context).push(
                                    MaterialPageRoute(
                                      builder: (_) => TrainingSessionFormScreen(
                                        trainerId: widget.trainerId,
                                        memberId: widget.memberId,
                                        initialDate: _selectedDate,
                                      ),
                                    ),
                                  );
                                  if (result == true) {
                                    _loadData();
                                  }
                                },
                                child: const Text('Tambah Sesi Pelatihan'),
                              ),
                            ],
                          ),
                        )
                      : ListView.builder(
                          itemCount: _sessions.length,
                          itemBuilder: (context, index) {
                            final session = _sessions[index];
                            final trainer = _trainers[session.trainerId];
                            final member = _members[session.memberId];
                            
                            if (trainer == null || member == null) {
                              return const SizedBox.shrink();
                            }
                            
                            return Card(
                              margin: const EdgeInsets.symmetric(
                                horizontal: 16,
                                vertical: 8,
                              ),
                              child: Padding(
                                padding: const EdgeInsets.all(16),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text(
                                          DateFormatter.formatDate(session.sessionDate),
                                          style: const TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontSize: 16,
                                          ),
                                        ),
                                        Container(
                                          padding: const EdgeInsets.symmetric(
                                            horizontal: 8,
                                            vertical: 4,
                                          ),
                                          decoration: BoxDecoration(
                                            color: session.endTime == null ? Colors.orange : Colors.green,
                                            borderRadius: BorderRadius.circular(4),
                                          ),
                                          child: Text(
                                            session.endTime == null ? 'Berlangsung' : 'Selesai',
                                            style: const TextStyle(
                                              color: Colors.white,
                                              fontSize: 12,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 8),
                                    if (widget.trainerId == null)
                                      Text(
                                        'Pelatih: ${trainer.name}',
                                        style: const TextStyle(
                                          fontSize: 16,
                                        ),
                                      ),
                                    if (widget.memberId == null)
                                      Text(
                                        'Anggota: ${member.name}',
                                        style: const TextStyle(
                                          fontSize: 16,
                                        ),
                                      ),
                                    Text(
                                      'Waktu: ${DateFormatter.formatTime(session.startTime)} - ${session.endTime != null ? DateFormatter.formatTime(session.endTime) : 'Belum selesai'}',
                                    ),
                                    if (session.notes != null && session.notes!.isNotEmpty)
                                      Text(
                                        'Catatan: ${session.notes}',
                                        style: const TextStyle(
                                          fontStyle: FontStyle.italic,
                                        ),
                                      ),
                                    const SizedBox(height: 16),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      children: [
                                        if (session.endTime == null)
                                          TextButton.icon(
                                            onPressed: () async {
                                              final now = DateTime.now();
                                              final endTime = DateFormat('HH:mm:ss').format(now);
                                              
                                              final updatedSession = TrainingSession(
                                                id: session.id,
                                                trainerId: session.trainerId,
                                                memberId: session.memberId,
                                                sessionDate: session.sessionDate,
                                                startTime: session.startTime,
                                                endTime: endTime,
                                                notes: session.notes,
                                              );
                                              
                                              await _sessionRepository.updateTrainingSession(updatedSession);
                                              _loadData();
                                            },
                                            icon: const Icon(Icons.check_circle),
                                            label: const Text('Selesai'),
                                          ),
                                        const SizedBox(width: 8),
                                        TextButton.icon(
                                          onPressed: () async {
                                            final result = await Navigator.of(context).push(
                                              MaterialPageRoute(
                                                builder: (_) => TrainingSessionFormScreen(
                                                  session: session,
                                                ),
                                              ),
                                            );
                                            if (result == true) {
                                              _loadData();
                                            }
                                          },
                                          icon: const Icon(Icons.edit),
                                          label: const Text('Edit'),
                                        ),
                                        const SizedBox(width: 8),
                                        TextButton.icon(
                                          onPressed: () {
                                            showDialog(
                                              context: context,
                                              builder: (context) => AlertDialog(
                                                title: const Text('Konfirmasi'),
                                                content: const Text(
                                                    'Apakah Anda yakin ingin menghapus sesi pelatihan ini?'),
                                                actions: [
                                                  TextButton(
                                                    onPressed: () => Navigator.of(context).pop(),
                                                    child: const Text('Batal'),
                                                  ),
                                                  TextButton(
                                                    onPressed: () {
                                                      Navigator.of(context).pop();
                                                      _deleteSession(session.id!);
                                                    },
                                                    child: const Text('Hapus'),
                                                  ),
                                                ],
                                              ),
                                            );
                                          },
                                          icon: const Icon(Icons.delete, color: Colors.red),
                                          label: const Text('Hapus', style: TextStyle(color: Colors.red)),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                ),
              ],
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final result = await Navigator.of(context).push(
            MaterialPageRoute(
              builder: (_) => TrainingSessionFormScreen(
                trainerId: widget.trainerId,
                memberId: widget.memberId,
                initialDate: _selectedDate,
              ),
            ),
          );
          if (result == true) {
            _loadData();
          }
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}
