import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:gym/models/member.dart';
import 'package:gym/models/membership_package.dart';
import 'package:gym/models/subscription.dart';
import 'package:gym/repositories/member_repository.dart';
import 'package:gym/repositories/membership_package_repository.dart';
import 'package:gym/repositories/subscription_repository.dart';
import 'package:gym/screens/payments/payment_form_screen.dart';
import 'package:gym/screens/subscriptions/subscription_form_screen.dart';
import 'package:gym/utils/currency_formatter.dart';
import 'package:gym/utils/date_formatter.dart';

class SubscriptionListScreen extends StatefulWidget {
  const SubscriptionListScreen({super.key});

  @override
  State<SubscriptionListScreen> createState() => _SubscriptionListScreenState();
}

class _SubscriptionListScreenState extends State<SubscriptionListScreen> {
  final SubscriptionRepository _subscriptionRepository = SubscriptionRepository();
  final MemberRepository _memberRepository = MemberRepository();
  final MembershipPackageRepository _packageRepository = MembershipPackageRepository();
  
  List<Subscription> _subscriptions = [];
  Map<int, Member> _members = {};
  Map<int, MembershipPackage> _packages = {};
  
  bool _isLoading = true;
  String _filter = 'all'; // all, active, inactive, expired

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() {
      _isLoading = true;
    });

    try {
      // Load subscriptions based on filter
      List<Subscription> subscriptions;
      switch (_filter) {
        case 'active':
          subscriptions = await _subscriptionRepository.getActiveSubscriptions();
          break;
        case 'expired':
          subscriptions = await _subscriptionRepository.getExpiredSubscriptions();
          break;
        default:
          subscriptions = await _subscriptionRepository.getAllSubscriptions();
      }
      
      // Load all members and packages
      final members = await _memberRepository.getAllMembers();
      final packages = await _packageRepository.getAllPackages();
      
      // Create maps for quick lookup
      final memberMap = {for (var m in members) m.id!: m};
      final packageMap = {for (var p in packages) p.id!: p};
      
      setState(() {
        _subscriptions = subscriptions;
        _members = memberMap;
        _packages = packageMap;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error: ${e.toString()}'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> _deleteSubscription(int id) async {
    try {
      await _subscriptionRepository.deleteSubscription(id);
      await _loadData();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Langganan berhasil dihapus'),
            backgroundColor: Colors.green,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error: ${e.toString()}'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Color _getStatusColor(String status) {
    switch (status) {
      case 'active':
        return Colors.green;
      case 'inactive':
        return Colors.orange;
      case 'expired':
        return Colors.red;
      default:
        return Colors.grey;
    }
  }

  String _getStatusText(String status) {
    switch (status) {
      case 'active':
        return 'Aktif';
      case 'inactive':
        return 'Tidak Aktif';
      case 'expired':
        return 'Kadaluarsa';
      default:
        return 'Tidak Diketahui';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Daftar Langganan'),
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.filter_list),
            onSelected: (value) {
              setState(() {
                _filter = value;
              });
              _loadData();
            },
            itemBuilder: (context) => [
              const PopupMenuItem(
                value: 'all',
                child: Text('Semua'),
              ),
              const PopupMenuItem(
                value: 'active',
                child: Text('Aktif'),
              ),
              const PopupMenuItem(
                value: 'expired',
                child: Text('Kadaluarsa'),
              ),
            ],
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _subscriptions.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Text('Tidak ada data langganan'),
                      const SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: () async {
                          final result = await Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (_) => const SubscriptionFormScreen(),
                            ),
                          );
                          if (result == true) {
                            _loadData();
                          }
                        },
                        child: const Text('Tambah Langganan'),
                      ),
                    ],
                  ),
                )
              : RefreshIndicator(
                  onRefresh: _loadData,
                  child: ListView.builder(
                    itemCount: _subscriptions.length,
                    itemBuilder: (context, index) {
                      final subscription = _subscriptions[index];
                      final member = _members[subscription.memberId];
                      final package = _packages[subscription.packageId];
                      
                      if (member == null || package == null) {
                        return const SizedBox.shrink();
                      }
                      
                      return Card(
                        margin: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 8,
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Expanded(
                                    child: Text(
                                      member.name,
                                      style: const TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 8,
                                      vertical: 4,
                                    ),
                                    decoration: BoxDecoration(
                                      color: _getStatusColor(subscription.status),
                                      borderRadius: BorderRadius.circular(4),
                                    ),
                                    child: Text(
                                      _getStatusText(subscription.status),
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontSize: 12,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 8),
                              Text(
                                'Paket: ${package.name}',
                                style: const TextStyle(
                                  fontSize: 16,
                                ),
                              ),
                              Text(
                                'Harga: ${CurrencyFormatter.format(package.price)}',
                              ),
                              Text(
                                'Periode: ${DateFormatter.formatDate(subscription.startDate)} - ${DateFormatter.formatDate(subscription.endDate)}',
                              ),
                              const SizedBox(height: 16),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  TextButton.icon(
                                    onPressed: () {
                                      Navigator.of(context).push(
                                        MaterialPageRoute(
                                          builder: (_) => PaymentFormScreen(
                                            subscriptionId: subscription.id,
                                          ),
                                        ),
                                      );
                                    },
                                    icon: const Icon(Icons.payment),
                                    label: const Text('Bayar'),
                                  ),
                                  const SizedBox(width: 8),
                                  TextButton.icon(
                                    onPressed: () async {
                                      final result = await Navigator.of(context).push(
                                        MaterialPageRoute(
                                          builder: (_) => SubscriptionFormScreen(
                                            subscription: subscription,
                                          ),
                                        ),
                                      );
                                      if (result == true) {
                                        _loadData();
                                      }
                                    },
                                    icon: const Icon(Icons.edit),
                                    label: const Text('Edit'),
                                  ),
                                  const SizedBox(width: 8),
                                  TextButton.icon(
                                    onPressed: () {
                                      showDialog(
                                        context: context,
                                        builder: (context) => AlertDialog(
                                          title: const Text('Konfirmasi'),
                                          content: const Text(
                                              'Apakah Anda yakin ingin menghapus langganan ini?'),
                                          actions: [
                                            TextButton(
                                              onPressed: () => Navigator.of(context).pop(),
                                              child: const Text('Batal'),
                                            ),
                                            TextButton(
                                              onPressed: () {
                                                Navigator.of(context).pop();
                                                _deleteSubscription(subscription.id!);
                                              },
                                              child: const Text('Hapus'),
                                            ),
                                          ],
                                        ),
                                      );
                                    },
                                    icon: const Icon(Icons.delete, color: Colors.red),
                                    label: const Text('Hapus', style: TextStyle(color: Colors.red)),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final result = await Navigator.of(context).push(
            MaterialPageRoute(
              builder: (_) => const SubscriptionFormScreen(),
            ),
          );
          if (result == true) {
            _loadData();
          }
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}
