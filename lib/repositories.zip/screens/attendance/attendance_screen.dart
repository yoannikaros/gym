import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:gym/models/attendance.dart';
import 'package:gym/models/member.dart';
import 'package:gym/repositories/member_repository.dart';
import 'package:gym/repositories/attendance_repository.dart';

class AttendanceScreen extends StatefulWidget {
  const AttendanceScreen({super.key});

  @override
  State<AttendanceScreen> createState() => _AttendanceScreenState();
}

class _AttendanceScreenState extends State<AttendanceScreen> {
  final MemberRepository _memberRepository = MemberRepository();
  final AttendanceRepository _attendanceRepository = AttendanceRepository();
  
  List<Member> _members = [];
  List<Member> _filteredMembers = [];
  List<Attendance> _todayAttendance = [];
  
  DateTime _selectedDate = DateTime.now();
  bool _isLoading = true;
  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadData() async {
    setState(() {
      _isLoading = true;
    });

    try {
      // Load members
      final members = await _memberRepository.getAllMembers();
      
      // Load today's attendance
      final formattedDate = DateFormat('yyyy-MM-dd').format(_selectedDate);
      final attendance = await _attendanceRepository.getAttendanceByDate(formattedDate);
      
      setState(() {
        _members = members;
        _filteredMembers = members;
        _todayAttendance = attendance;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error: ${e.toString()}'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  void _filterMembers(String query) {
    if (query.isEmpty) {
      setState(() {
        _filteredMembers = _members;
      });
    } else {
      setState(() {
        _filteredMembers = _members
            .where((member) =>
                member.name.toLowerCase().contains(query.toLowerCase()) ||
                (member.phone != null &&
                    member.phone!.toLowerCase().contains(query.toLowerCase())))
            .toList();
      });
    }
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime(2000),
      lastDate: DateTime.now(),
    );
    
    if (picked != null && picked != _selectedDate) {
      setState(() {
        _selectedDate = picked;
      });
      _loadData();
    }
  }

  Future<void> _recordAttendance(Member member) async {
    try {
      final now = DateTime.now();
      final formattedDateTime = DateFormat('yyyy-MM-dd HH:mm:ss').format(now);
      
      // Cek apakah member sudah absen hari ini
      final existingAttendance = _todayAttendance
          .where((a) => a.memberId == member.id)
          .toList();
      
      if (existingAttendance.isEmpty) {
        // Check in
        final attendance = Attendance(
          memberId: member.id!,
          checkIn: formattedDateTime,
        );
        
        await _attendanceRepository.insertAttendance(attendance);
        
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('${member.name} berhasil check in'),
              backgroundColor: Colors.green,
            ),
          );
        }
      } else {
        // Check out
        final attendance = existingAttendance.first;
        final updatedAttendance = Attendance(
          id: attendance.id,
          memberId: attendance.memberId,
          checkIn: attendance.checkIn,
          checkOut: formattedDateTime,
        );
        
        await _attendanceRepository.updateAttendance(updatedAttendance);
        
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('${member.name} berhasil check out'),
              backgroundColor: Colors.orange,
            ),
          );
        }
      }
      
      _loadData();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error: ${e.toString()}'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Absensi Anggota'),
        actions: [
          IconButton(
            icon: const Icon(Icons.calendar_today),
            onPressed: () => _selectDate(context),
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Tanggal: ${DateFormat('dd MMMM yyyy').format(_selectedDate)}',
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 16),
                      TextField(
                        controller: _searchController,
                        decoration: const InputDecoration(
                          labelText: 'Cari Anggota',
                          prefixIcon: Icon(Icons.search),
                          border: OutlineInputBorder(),
                        ),
                        onChanged: _filterMembers,
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: _filteredMembers.isEmpty
                      ? const Center(child: Text('Tidak ada anggota'))
                      : ListView.builder(
                          itemCount: _filteredMembers.length,
                          itemBuilder: (context, index) {
                            final member = _filteredMembers[index];
                            
                            // Cek status absensi
                            final attendance = _todayAttendance
                                .where((a) => a.memberId == member.id)
                                .toList();
                            
                            final hasCheckedIn = attendance.isNotEmpty;
                            final hasCheckedOut = hasCheckedIn && 
                                attendance.first.checkOut != null;
                            
                            return Card(
                              margin: const EdgeInsets.symmetric(
                                horizontal: 16,
                                vertical: 8,
                              ),
                              child: ListTile(
                                leading: CircleAvatar(
                                  backgroundColor: Colors.green,
                                  child: Text(
                                    member.name.substring(0, 1).toUpperCase(),
                                    style: const TextStyle(color: Colors.white),
                                  ),
                                ),
                                title: Text(member.name),
                                subtitle: Text(member.phone ?? 'Tidak ada nomor telepon'),
                                trailing: ElevatedButton(
                                  onPressed: () => _recordAttendance(member),
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: hasCheckedIn
                                        ? hasCheckedOut
                                            ? Colors.grey
                                            : Colors.orange
                                        : Colors.green,
                                  ),
                                  child: Text(
                                    hasCheckedIn
                                        ? hasCheckedOut
                                            ? 'Selesai'
                                            : 'Check Out'
                                        : 'Check In',
                                    style: const TextStyle(color: Colors.white),
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
                ),
              ],
            ),
    );
  }
}
