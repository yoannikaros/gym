import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:gym/models/member.dart';
import 'package:gym/models/membership_package.dart';
import 'package:gym/models/payment.dart';
import 'package:gym/models/subscription.dart';
import 'package:gym/repositories/member_repository.dart';
import 'package:gym/repositories/membership_package_repository.dart';
import 'package:gym/repositories/payment_repository.dart';
import 'package:gym/repositories/subscription_repository.dart';
import 'package:gym/screens/payments/payment_form_screen.dart';
import 'package:gym/screens/payments/receipt_screen.dart';
import 'package:gym/utils/currency_formatter.dart';
import 'package:gym/utils/date_formatter.dart';

class PaymentListScreen extends StatefulWidget {
  final int? memberId;
  final int? subscriptionId;

  const PaymentListScreen({
    super.key,
    this.memberId,
    this.subscriptionId,
  });

  @override
  State<PaymentListScreen> createState() => _PaymentListScreenState();
}

class _PaymentListScreenState extends State<PaymentListScreen> {
  final PaymentRepository _paymentRepository = PaymentRepository();
  final SubscriptionRepository _subscriptionRepository = SubscriptionRepository();
  final MemberRepository _memberRepository = MemberRepository();
  final MembershipPackageRepository _packageRepository = MembershipPackageRepository();
  
  List<Payment> _payments = [];
  Map<int, Subscription> _subscriptions = {};
  Map<int, Member> _members = {};
  Map<int, MembershipPackage> _packages = {};
  
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() {
      _isLoading = true;
    });

    try {
      List<Payment> payments;
      
      // Filter payments if needed
      if (widget.subscriptionId != null) {
        payments = await _paymentRepository.getPaymentsBySubscriptionId(widget.subscriptionId!);
      } else if (widget.memberId != null) {
        // Get all subscriptions for this member
        final memberSubscriptions = await _subscriptionRepository.getSubscriptionsByMemberId(widget.memberId!);
        
        // Get payments for all these subscriptions
        payments = [];
        for (var subscription in memberSubscriptions) {
          final subscriptionPayments = await _paymentRepository.getPaymentsBySubscriptionId(subscription.id!);
          payments.addAll(subscriptionPayments);
        }
      } else {
        payments = await _paymentRepository.getAllPayments();
      }
      
      // Get all related subscriptions
      final subscriptionIds = payments.map((p) => p.subscriptionId).toSet().toList();
      final subscriptionMap = <int, Subscription>{};
      
      for (var id in subscriptionIds) {
        final subscription = await _subscriptionRepository.getSubscriptionById(id);
        if (subscription != null) {
          subscriptionMap[id] = subscription;
        }
      }
      
      // Get all related members and packages
      final memberIds = subscriptionMap.values.map((s) => s.memberId).toSet().toList();
      final packageIds = subscriptionMap.values.map((s) => s.packageId).toSet().toList();
      
      final memberMap = <int, Member>{};
      final packageMap = <int, MembershipPackage>{};
      
      for (var id in memberIds) {
        final member = await _memberRepository.getMemberById(id);
        if (member != null) {
          memberMap[id] = member;
        }
      }
      
      for (var id in packageIds) {
        final package = await _packageRepository.getPackageById(id);
        if (package != null) {
          packageMap[id] = package;
        }
      }
      
      setState(() {
        _payments = payments;
        _subscriptions = subscriptionMap;
        _members = memberMap;
        _packages = packageMap;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error: ${e.toString()}'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> _deletePayment(int id) async {
    try {
      await _paymentRepository.deletePayment(id);
      await _loadData();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Pembayaran berhasil dihapus'),
            backgroundColor: Colors.green,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error: ${e.toString()}'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  String _getPaymentMethodName(String? method) {
    switch (method) {
      case 'cash':
        return 'Tunai';
      case 'transfer':
        return 'Transfer Bank';
      case 'qris':
        return 'QRIS';
      case 'other':
        return 'Lainnya';
      default:
        return 'Tunai';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Daftar Pembayaran'),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _payments.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Text('Tidak ada data pembayaran'),
                      const SizedBox(height: 16),
                      if (widget.subscriptionId != null)
                        ElevatedButton(
                          onPressed: () async {
                            final result = await Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (_) => PaymentFormScreen(
                                  subscriptionId: widget.subscriptionId,
                                ),
                              ),
                            );
                            if (result == true) {
                              _loadData();
                            }
                          },
                          child: const Text('Tambah Pembayaran'),
                        ),
                    ],
                  ),
                )
              : RefreshIndicator(
                  onRefresh: _loadData,
                  child: ListView.builder(
                    itemCount: _payments.length,
                    itemBuilder: (context, index) {
                      final payment = _payments[index];
                      final subscription = _subscriptions[payment.subscriptionId];
                      
                      if (subscription == null) {
                        return const SizedBox.shrink();
                      }
                      
                      final member = _members[subscription.memberId];
                      final package = _packages[subscription.packageId];
                      
                      if (member == null || package == null) {
                        return const SizedBox.shrink();
                      }
                      
                      return Card(
                        margin: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 8,
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Expanded(
                                    child: Text(
                                      member.name,
                                      style: const TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                  Text(
                                    DateFormatter.formatDate(payment.paymentDate),
                                    style: const TextStyle(
                                      color: Colors.grey,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 8),
                              Text(
                                'Paket: ${package.name}',
                                style: const TextStyle(
                                  fontSize: 16,
                                ),
                              ),
                              Text(
                                'Metode: ${_getPaymentMethodName(payment.paymentMethod)}',
                              ),
                              Text(
                                'Jumlah: ${CurrencyFormatter.format(payment.amount)}',
                                style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: Colors.green,
                                ),
                              ),
                              if (payment.note != null && payment.note!.isNotEmpty)
                                Text(
                                  'Catatan: ${payment.note}',
                                  style: const TextStyle(
                                    fontStyle: FontStyle.italic,
                                  ),
                                ),
                              const SizedBox(height: 16),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  TextButton.icon(
                                    onPressed: () {
                                      Navigator.of(context).push(
                                        MaterialPageRoute(
                                          builder: (_) => ReceiptScreen(
                                            payment: payment,
                                            subscription: subscription,
                                            member: member,
                                            package: package,
                                          ),
                                        ),
                                      );
                                    },
                                    icon: const Icon(Icons.receipt),
                                    label: const Text('Lihat Struk'),
                                  ),
                                  const SizedBox(width: 8),
                                  TextButton.icon(
                                    onPressed: () async {
                                      final result = await Navigator.of(context).push(
                                        MaterialPageRoute(
                                          builder: (_) => PaymentFormScreen(
                                            payment: payment,
                                          ),
                                        ),
                                      );
                                      if (result == true) {
                                        _loadData();
                                      }
                                    },
                                    icon: const Icon(Icons.edit),
                                    label: const Text('Edit'),
                                  ),
                                  const SizedBox(width: 8),
                                  TextButton.icon(
                                    onPressed: () {
                                      showDialog(
                                        context: context,
                                        builder: (context) => AlertDialog(
                                          title: const Text('Konfirmasi'),
                                          content: const Text(
                                              'Apakah Anda yakin ingin menghapus pembayaran ini?'),
                                          actions: [
                                            TextButton(
                                              onPressed: () => Navigator.of(context).pop(),
                                              child: const Text('Batal'),
                                            ),
                                            TextButton(
                                              onPressed: () {
                                                Navigator.of(context).pop();
                                                _deletePayment(payment.id!);
                                              },
                                              child: const Text('Hapus'),
                                            ),
                                          ],
                                        ),
                                      );
                                    },
                                    icon: const Icon(Icons.delete, color: Colors.red),
                                    label: const Text('Hapus', style: TextStyle(color: Colors.red)),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
      floatingActionButton: widget.subscriptionId != null
          ? FloatingActionButton(
              onPressed: () async {
                final result = await Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) => PaymentFormScreen(
                      subscriptionId: widget.subscriptionId,
                    ),
                  ),
                );
                if (result == true) {
                  _loadData();
                }
              },
              child: const Icon(Icons.add),
            )
          : null,
    );
  }
}
