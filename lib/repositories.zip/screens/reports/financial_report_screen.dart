import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:gym/repositories/report_repository.dart';
import 'package:gym/utils/chart_data.dart';
import 'package:gym/utils/currency_formatter.dart' as app_currency;

class FinancialReportScreen extends StatefulWidget {
  const FinancialReportScreen({super.key});

  @override
  State<FinancialReportScreen> createState() => _FinancialReportScreenState();
}

class _FinancialReportScreenState extends State<FinancialReportScreen> {
  final ReportRepository _reportRepository = ReportRepository();
  
  bool _isLoading = true;
  String _periodType = 'month'; // 'day', 'month', 'year'
  DateTime _startDate = DateTime.now().subtract(const Duration(days: 30));
  DateTime _endDate = DateTime.now();
  
  Map<String, dynamic> _summary = {};
  List<Map<String, dynamic>> _chartData = [];
  List<Map<String, dynamic>> _topPackages = [];
  List<Map<String, dynamic>> _expenseCategories = [];

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() {
      _isLoading = true;
    });

    try {
      // Mendapatkan ringkasan keuangan
      final summary = await _reportRepository.getFinancialSummary(
        _startDate,
        _endDate,
      );
      
      // Mendapatkan data grafik berdasarkan periode
      List<Map<String, dynamic>> chartData;
      if (_periodType == 'day') {
        chartData = await _reportRepository.getDailyFinancialData(
          _startDate,
          _endDate,
        );
      } else {
        chartData = await _reportRepository.getMonthlyFinancialData(
          _startDate,
          _endDate,
        );
      }
      
      // Mendapatkan data paket terlaris
      final topPackages = await _reportRepository.getTopMembershipPackages(
        _startDate,
        _endDate,
      );
      
      // Mendapatkan data kategori pengeluaran
      final expenseCategories = await _reportRepository.getExpenseCategories(
        _startDate,
        _endDate,
      );
      
      setState(() {
        _summary = summary;
        _chartData = chartData;
        _topPackages = topPackages;
        _expenseCategories = expenseCategories;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error: ${e.toString()}'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> _selectDateRange(BuildContext context) async {
    final DateTimeRange? picked = await showDateRangePicker(
      context: context,
      initialDateRange: DateTimeRange(
        start: _startDate,
        end: _endDate,
      ),
      firstDate: DateTime(2000),
      lastDate: DateTime.now(),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: const ColorScheme.light(
              primary: Colors.green,
              onPrimary: Colors.white,
              onSurface: Colors.black,
            ),
          ),
          child: child!,
        );
      },
    );
    
    if (picked != null) {
      setState(() {
        _startDate = picked.start;
        _endDate = picked.end;
      });
      _loadData();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Laporan Keuangan'),
        actions: [
          IconButton(
            icon: const Icon(Icons.calendar_today),
            onPressed: () => _selectDateRange(context),
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Periode dan Filter
                  _buildPeriodFilter(),
                  
                  // Ringkasan Keuangan
                  _buildFinancialSummary(),
                  
                  // Grafik Pendapatan & Pengeluaran
                  _buildIncomeExpenseChart(),
                  
                  // Grafik Keuntungan
                  _buildProfitChart(),
                  
                  // Paket Terlaris
                  _buildTopPackagesChart(),
                  
                  // Kategori Pengeluaran
                  _buildExpenseCategoriesChart(),
                ],
              ),
            ),
    );
  }

  Widget _buildPeriodFilter() {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Periode: ${DateFormat('dd MMM yyyy').format(_startDate)} - ${DateFormat('dd MMM yyyy').format(_endDate)}',
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                _buildFilterChip('Harian', 'day'),
                const SizedBox(width: 8),
                _buildFilterChip('Bulanan', 'month'),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFilterChip(String label, String value) {
    return FilterChip(
      label: Text(label),
      selected: _periodType == value,
      onSelected: (selected) {
        if (selected) {
          setState(() {
            _periodType = value;
          });
          _loadData();
        }
      },
      selectedColor: Colors.green.withOpacity(0.2),
      checkmarkColor: Colors.green,
    );
  }

  Widget _buildFinancialSummary() {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Ringkasan Keuangan',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: _buildSummaryItem(
                    'Total Pendapatan',
                    app_currency.CurrencyFormatter.format(_summary['total_income'] ?? 0),
                    Colors.green,
                  ),
                ),
                Expanded(
                  child: _buildSummaryItem(
                    'Total Pengeluaran',
                    app_currency.CurrencyFormatter.format(_summary['total_expense'] ?? 0),
                    Colors.red,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: _buildSummaryItem(
                    'Keuntungan Bersih',
                    app_currency.CurrencyFormatter.format(_summary['net_profit'] ?? 0),
                    Colors.blue,
                  ),
                ),
                Expanded(
                  child: _buildSummaryItem(
                    'Saldo Tabungan',
                    app_currency.CurrencyFormatter.format(_summary['savings_balance'] ?? 0),
                    Colors.amber,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSummaryItem(String label, String value, Color color) {
    return Column(
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: 14,
            color: Colors.grey[600],
          ),
        ),
        const SizedBox(height: 4),
        Text(
          value,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: color,
          ),
        ),
      ],
    );
  }

  Widget _buildIncomeExpenseChart() {
    if (_chartData.isEmpty) {
      return const SizedBox.shrink();
    }

    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Pendapatan & Pengeluaran',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            SizedBox(
              height: 300,
              child: _chartData.length <= 1
                  ? const Center(child: Text('Data tidak cukup untuk menampilkan grafik'))
                  : BarChart(
                      BarChartData(
                        alignment: BarChartAlignment.spaceAround,
                        maxY: _getMaxValue() * 1.2,
                        barTouchData: BarTouchData(
                          touchTooltipData: BarTouchTooltipData(
                            tooltipBgColor: Colors.blueGrey,
                            getTooltipItem: (group, groupIndex, rod, rodIndex) {
                              String label = _periodType == 'day'
                                  ? _chartData[group.x.toInt()]['formatted_date']
                                  : _chartData[group.x.toInt()]['formatted_month'];
                              
                              String value = app_currency.CurrencyFormatter.format(rod.toY);
                              String type = rodIndex == 0 ? 'Pendapatan' : 'Pengeluaran';
                              
                              return BarTooltipItem(
                                '$label\n$type: $value',
                                const TextStyle(color: Colors.white),
                              );
                            },
                          ),
                        ),
                        titlesData: FlTitlesData(
                          show: true,
                          bottomTitles: AxisTitles(
                            sideTitles: SideTitles(
                              showTitles: true,
                              getTitlesWidget: (value, meta) {
                                if (value.toInt() >= _chartData.length) {
                                  return const SizedBox.shrink();
                                }
                                
                                String label = _periodType == 'day'
                                    ? DateFormat('dd/MM').format(DateTime.parse(_chartData[value.toInt()]['date']))
                                    : DateFormat('MMM').format(DateTime.parse(_chartData[value.toInt()]['month'] + '-01'));
                                
                                return Padding(
                                  padding: const EdgeInsets.only(top: 8.0),
                                  child: Text(
                                    label,
                                    style: const TextStyle(
                                      fontSize: 10,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                );
                              },
                            ),
                          ),
                          leftTitles: AxisTitles(
                            sideTitles: SideTitles(
                              showTitles: true,
                              reservedSize: 60,
                              getTitlesWidget: (value, meta) {
                                return Text(
                                  CurrencyFormatter.formatCompact(value),
                                  style: const TextStyle(fontSize: 10),
                                );
                              },
                            ),
                          ),
                          topTitles: const AxisTitles(
                            sideTitles: SideTitles(showTitles: false),
                          ),
                          rightTitles: const AxisTitles(
                            sideTitles: SideTitles(showTitles: false),
                          ),
                        ),
                        gridData: FlGridData(
                          show: true,
                          drawVerticalLine: false,
                          getDrawingHorizontalLine: (value) {
                            return FlLine(
                              color: Colors.grey.withOpacity(0.2),
                              strokeWidth: 1,
                            );
                          },
                        ),
                        borderData: FlBorderData(
                          show: false,
                        ),
                        barGroups: List.generate(_chartData.length, (index) {
                          return BarChartGroupData(
                            x: index,
                            barRods: [
                              BarChartRodData(
                                toY: _chartData[index]['total_income'],
                                color: Colors.green,
                                width: 16,
                                borderRadius: const BorderRadius.only(
                                  topLeft: Radius.circular(4),
                                  topRight: Radius.circular(4),
                                ),
                              ),
                              BarChartRodData(
                                toY: _chartData[index]['expense'],
                                color: Colors.red,
                                width: 16,
                                borderRadius: const BorderRadius.only(
                                  topLeft: Radius.circular(4),
                                  topRight: Radius.circular(4),
                                ),
                              ),
                            ],
                          );
                        }),
                      ),
                    ),
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _buildLegendItem('Pendapatan', Colors.green),
                const SizedBox(width: 24),
                _buildLegendItem('Pengeluaran', Colors.red),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProfitChart() {
    if (_chartData.isEmpty) {
      return const SizedBox.shrink();
    }

    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Keuntungan',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            SizedBox(
              height: 300,
              child: _chartData.length <= 1
                  ? const Center(child: Text('Data tidak cukup untuk menampilkan grafik'))
                  : LineChart(
                      LineChartData(
                        lineTouchData: LineTouchData(
                          touchTooltipData: LineTouchTooltipData(
                            tooltipBgColor: Colors.blueGrey,
                            getTooltipItems: (touchedSpots) {
                              return touchedSpots.map((spot) {
                                String label = _periodType == 'day'
                                    ? _chartData[spot.x.toInt()]['formatted_date']
                                    : _chartData[spot.x.toInt()]['formatted_month'];
                                
                                String value = app_currency.CurrencyFormatter.format(spot.y);
                                
                                return LineTooltipItem(
                                  '$label\nKeuntungan: $value',
                                  const TextStyle(color: Colors.white),
                                );
                              }).toList();
                            },
                          ),
                        ),
                        titlesData: FlTitlesData(
                          show: true,
                          bottomTitles: AxisTitles(
                            sideTitles: SideTitles(
                              showTitles: true,
                              getTitlesWidget: (value, meta) {
                                if (value.toInt() >= _chartData.length) {
                                  return const SizedBox.shrink();
                                }
                                
                                String label = _periodType == 'day'
                                    ? DateFormat('dd/MM').format(DateTime.parse(_chartData[value.toInt()]['date']))
                                    : DateFormat('MMM').format(DateTime.parse(_chartData[value.toInt()]['month'] + '-01'));
                                
                                return Padding(
                                  padding: const EdgeInsets.only(top: 8.0),
                                  child: Text(
                                    label,
                                    style: const TextStyle(
                                      fontSize: 10,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                );
                              },
                            ),
                          ),
                          leftTitles: AxisTitles(
                            sideTitles: SideTitles(
                              showTitles: true,
                              reservedSize: 60,
                              getTitlesWidget: (value, meta) {
                                return Text(
                                  CurrencyFormatter.formatCompact(value),
                                  style: const TextStyle(fontSize: 10),
                                );
                              },
                            ),
                          ),
                          topTitles: const AxisTitles(
                            sideTitles: SideTitles(showTitles: false),
                          ),
                          rightTitles: const AxisTitles(
                            sideTitles: SideTitles(showTitles: false),
                          ),
                        ),
                        gridData: FlGridData(
                          show: true,
                          drawVerticalLine: false,
                          getDrawingHorizontalLine: (value) {
                            return FlLine(
                              color: Colors.grey.withOpacity(0.2),
                              strokeWidth: 1,
                            );
                          },
                        ),
                        borderData: FlBorderData(
                          show: false,
                        ),
                        minY: _getMinProfitValue() * 1.2,
                        maxY: _getMaxProfitValue() * 1.2,
                        lineBarsData: [
                          LineChartBarData(
                            spots: List.generate(_chartData.length, (index) {
                              return FlSpot(
                                index.toDouble(),
                                _chartData[index]['profit'],
                              );
                            }),
                            isCurved: true,
                            color: Colors.blue,
                            barWidth: 3,
                            isStrokeCapRound: true,
                            dotData: const FlDotData(show: true),
                            belowBarData: BarAreaData(
                              show: true,
                              color: Colors.blue.withOpacity(0.2),
                            ),
                          ),
                        ],
                      ),
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTopPackagesChart() {
    if (_topPackages.isEmpty) {
      return const SizedBox.shrink();
    }

    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Paket Terlaris',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            SizedBox(
              height: 300,
              child: _topPackages.isEmpty
                  ? const Center(child: Text('Tidak ada data paket'))
                  : BarChart(
                      BarChartData(
                        alignment: BarChartAlignment.spaceAround,
                        maxY: _getMaxPackageCount() * 1.2,
                        barTouchData: BarTouchData(
                          touchTooltipData: BarTouchTooltipData(
                            tooltipBgColor: Colors.blueGrey,
                            getTooltipItem: (group, groupIndex, rod, rodIndex) {
                              String name = _topPackages[group.x.toInt()]['name'];
                              int count = _topPackages[group.x.toInt()]['subscription_count'];
                              double revenue = _topPackages[group.x.toInt()]['total_revenue'];
                              
                              return BarTooltipItem(
                                '$name\nJumlah: $count\nPendapatan: ${app_currency.CurrencyFormatter.format(revenue)}',
                                const TextStyle(color: Colors.white),
                              );
                            },
                          ),
                        ),
                        titlesData: FlTitlesData(
                          show: true,
                          bottomTitles: AxisTitles(
                            sideTitles: SideTitles(
                              showTitles: true,
                              getTitlesWidget: (value, meta) {
                                if (value.toInt() >= _topPackages.length) {
                                  return const SizedBox.shrink();
                                }
                                
                                String name = _topPackages[value.toInt()]['name'];
                                if (name.length > 10) {
                                  name = name.substring(0, 10) + '...';
                                }
                                
                                return Padding(
                                  padding: const EdgeInsets.only(top: 8.0),
                                  child: Text(
                                    name,
                                    style: const TextStyle(
                                      fontSize: 10,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                );
                              },
                            ),
                          ),
                          leftTitles: AxisTitles(
                            sideTitles: SideTitles(
                              showTitles: true,
                              getTitlesWidget: (value, meta) {
                                return Text(
                                  value.toInt().toString(),
                                  style: const TextStyle(fontSize: 10),
                                );
                              },
                            ),
                          ),
                          topTitles: const AxisTitles(
                            sideTitles: SideTitles(showTitles: false),
                          ),
                          rightTitles: const AxisTitles(
                            sideTitles: SideTitles(showTitles: false),
                          ),
                        ),
                        gridData: FlGridData(
                          show: true,
                          drawVerticalLine: false,
                          getDrawingHorizontalLine: (value) {
                            return FlLine(
                              color: Colors.grey.withOpacity(0.2),
                              strokeWidth: 1,
                            );
                          },
                        ),
                        borderData: FlBorderData(
                          show: false,
                        ),
                        barGroups: List.generate(_topPackages.length, (index) {
                          final List<Color> colors = [
                            Colors.blue,
                            Colors.green,
                            Colors.orange,
                            Colors.purple,
                            Colors.teal,
                          ];
                          
                          return BarChartGroupData(
                            x: index,
                            barRods: [
                              BarChartRodData(
                                toY: _topPackages[index]['subscription_count'].toDouble(),
                                color: colors[index % colors.length],
                                width: 20,
                                borderRadius: const BorderRadius.only(
                                  topLeft: Radius.circular(4),
                                  topRight: Radius.circular(4),
                                ),
                              ),
                            ],
                          );
                        }),
                      ),
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildExpenseCategoriesChart() {
    if (_expenseCategories.isEmpty) {
      return const SizedBox.shrink();
    }

    // Menghitung total pengeluaran
    double totalExpense = 0;
    for (var category in _expenseCategories) {
      totalExpense += category['total'];
    }

    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Kategori Pengeluaran',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            SizedBox(
              height: 300,
              child: _expenseCategories.isEmpty
                  ? const Center(child: Text('Tidak ada data pengeluaran'))
                  : Row(
                      children: [
                        Expanded(
                          flex: 3,
                          child: PieChart(
                            PieChartData(
                              sectionsSpace: 2,
                              centerSpaceRadius: 40,
                              sections: List.generate(_expenseCategories.length, (index) {
                                final List<Color> colors = [
                                  Colors.red,
                                  Colors.orange,
                                  Colors.amber,
                                  Colors.brown,
                                  Colors.grey,
                                ];
                                
                                final category = _expenseCategories[index];
                                final double percentage = (category['total'] / totalExpense) * 100;
                                
                                return PieChartSectionData(
                                  color: colors[index % colors.length],
                                  value: category['total'],
                                  title: '${percentage.toStringAsFixed(1)}%',
                                  radius: 100,
                                  titleStyle: const TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white,
                                  ),
                                );
                              }),
                            ),
                          ),
                        ),
                        Expanded(
                          flex: 2,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: List.generate(_expenseCategories.length, (index) {
                              final List<Color> colors = [
                                Colors.red,
                                Colors.orange,
                                Colors.amber,
                                Colors.brown,
                                Colors.grey,
                              ];
                              
                              final category = _expenseCategories[index];
                              
                              return Padding(
                                padding: const EdgeInsets.symmetric(vertical: 4),
                                child: Row(
                                  children: [
                                    Container(
                                      width: 12,
                                      height: 12,
                                      color: colors[index % colors.length],
                                    ),
                                    const SizedBox(width: 8),
                                    Expanded(
                                      child: Text(
                                        category['category'],
                                        style: const TextStyle(fontSize: 12),
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  ],
                                ),
                              );
                            }),
                          ),
                        ),
                      ],
                    ),
            ),
            const SizedBox(height: 16),
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: _expenseCategories.length,
              itemBuilder: (context, index) {
                final category = _expenseCategories[index];
                final double percentage = (category['total'] / totalExpense) * 100;
                
                return ListTile(
                  title: Text(category['category']),
                  subtitle: Text('${percentage.toStringAsFixed(1)}%'),
                  trailing: Text(
                    app_currency.CurrencyFormatter.format(category['total']),
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLegendItem(String label, Color color) {
    return Row(
      children: [
        Container(
          width: 16,
          height: 16,
          color: color,
        ),
        const SizedBox(width: 4),
        Text(label),
      ],
    );
  }

  double _getMaxValue() {
    double max = 0;
    for (var item in _chartData) {
      if (item['total_income'] > max) {
        max = item['total_income'];
      }
      if (item['expense'] > max) {
        max = item['expense'];
      }
    }
    return max;
  }

  double _getMaxProfitValue() {
    double max = 0;
    for (var item in _chartData) {
      if (item['profit'] > max) {
        max = item['profit'];
      }
    }
    return max;
  }

  double _getMinProfitValue() {
    double min = 0;
    for (var item in _chartData) {
      if (item['profit'] < min) {
        min = item['profit'];
      }
    }
    return min;
  }

  double _getMaxPackageCount() {
    double max = 0;
    for (var item in _topPackages) {
      if (item['subscription_count'] > max) {
        max = item['subscription_count'].toDouble();
      }
    }
    return max;
  }
}
